# coding=utf-8
from subzero.history_storage import SubtitleHistory

get_history = lambda: SubtitleHistory(Data, Thread, int(Prefs["history_size"]))
